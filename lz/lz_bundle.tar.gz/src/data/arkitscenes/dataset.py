from __future__ import annotations

from typing import Dict, List, Optional

from src.data.dataset_base import AnnotatedDataset
from src.utils import RankedLogger

log = RankedLogger(__name__, rank_zero_only=False)


class ARKitScenesDataset(AnnotatedDataset):
    CLASS_LABELS = []  # no GT semantic labels
    LOG_POSTFIX = "arkitscenes"

    def __init__(
        self,
        data_dir: str,
        split: str,
        ignore_label: int = -100,
        repeat: int = 1,
        transforms: Optional[List[Dict]] = None,
        num_masks: Optional[int] = None,
        anno_sources: Optional[List[str]] = None,
    ) -> None:
        super().__init__(
            data_dir=data_dir,
            split=split,
            repeat=repeat,
            ignore_label=ignore_label,
            transforms=transforms,
            num_masks=num_masks,
            anno_sources=anno_sources,
        )
