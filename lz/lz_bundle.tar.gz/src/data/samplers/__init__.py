"""Sampling strategies for long-tail learning."""

from .acbs_sampler import ACBSSampler

__all__ = ["ACBSSampler"]
