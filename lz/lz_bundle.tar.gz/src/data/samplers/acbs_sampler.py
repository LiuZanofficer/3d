"""
Adaptive Class-Balanced Sampler (ACBS)

This module implements the core long-tail learning strategy for LZ.
Uses sqrt-frequency reweighting with temperature annealing to ensure
tail classes get 5-10x more sampling during training.

Key Features:
- Sqrt-frequency reweighting: weight_c = 1/sqrt(freq_c)
- Temperature-controlled sampling: prob_c = weight_c^(1/tau)
- Dynamic temperature annealing: tau = 0.5 (early) -> 1.0 (late)
- Guaranteed minimum tail class ratio per batch (30-50%)

Author: LZ Team
"""

from __future__ import annotations

from collections import Counter
from typing import Dict, Iterator, List, Optional

import numpy as np
from torch.utils.data import Sampler


class ACBSSampler(Sampler[int]):
    """
    Adaptive Class-Balanced Sampler for long-tail 3D segmentation.

    Args:
        dataset: The dataset to sample from.
        class_freq: Dictionary mapping class_id to frequency count.
        temperature_start: Initial temperature for aggressive rebalancing (default: 0.5).
        temperature_end: Final temperature to converge to natural distribution (default: 1.0).
        tail_boost_factor: Additional boost for tail classes (default: 2.0).
        min_tail_ratio: Minimum ratio of tail class samples per batch (default: 0.3).
        num_epochs: Total number of epochs for temperature annealing.
        shuffle: Whether to shuffle samples.
        seed: Random seed for reproducibility.
    """

    def __init__(
        self,
        dataset,
        class_freq: Dict[int, int],
        temperature_start: float = 0.5,
        temperature_end: float = 1.0,
        tail_boost_factor: float = 2.0,
        min_tail_ratio: float = 0.3,
        num_epochs: int = 100,
        shuffle: bool = True,
        seed: int = 42,
    ) -> None:
        self.dataset = dataset
        self.class_freq = class_freq
        self.temperature_start = temperature_start
        self.temperature_end = temperature_end
        self.tail_boost_factor = tail_boost_factor
        self.min_tail_ratio = min_tail_ratio
        self.num_epochs = num_epochs
        self.shuffle = shuffle
        self.seed = seed

        # Current epoch (will be updated externally)
        self.current_epoch = 0

        # Identify head/common/tail classes based on frequency
        self._classify_classes()

        # Compute sampling weights
        self._compute_weights()

        # Build sample-to-class mapping
        self._build_sample_class_mapping()

        # Set random state
        self.rng = np.random.RandomState(seed)

    def _classify_classes(self) -> None:
        """Classify classes into head, common, and tail based on frequency."""
        sorted_classes = sorted(self.class_freq.items(), key=lambda x: x[1], reverse=True)
        num_classes = len(sorted_classes)

        # Split into 3 groups: head (top 33%), common (middle 34%), tail (bottom 33%)
        head_end = num_classes // 3
        common_end = 2 * num_classes // 3

        self.head_classes = set(cls for cls, _ in sorted_classes[:head_end])
        self.common_classes = set(cls for cls, _ in sorted_classes[head_end:common_end])
        self.tail_classes = set(cls for cls, _ in sorted_classes[common_end:])

    def _compute_weights(self) -> None:
        """Compute sqrt-frequency reweighting for each class."""
        self.class_weights = {}

        for class_id, freq in self.class_freq.items():
            # Sqrt-frequency reweighting
            base_weight = 1.0 / np.sqrt(max(freq, 1))

            # Apply additional boost for tail classes
            if class_id in self.tail_classes:
                base_weight *= self.tail_boost_factor

            self.class_weights[class_id] = base_weight

        # Normalize weights
        total_weight = sum(self.class_weights.values())
        if total_weight > 0:
            self.class_weights = {k: v / total_weight for k, v in self.class_weights.items()}

    def _build_sample_class_mapping(self) -> None:
        """Build mapping from sample index to dominant class."""
        self.sample_to_class = {}
        self.class_to_samples = {cls: [] for cls in self.class_freq.keys()}

        for idx in range(len(self.dataset)):
            # Get dominant class for this sample
            try:
                if hasattr(self.dataset, "get_dominant_class"):
                    dominant_class = self.dataset.get_dominant_class(idx)
                else:
                    # Fallback: distribute samples evenly
                    dominant_class = list(self.class_freq.keys())[idx % len(self.class_freq)]

                self.sample_to_class[idx] = dominant_class
                self.class_to_samples[dominant_class].append(idx)
            except Exception:
                # If we cannot determine class, assign to a deterministic class
                dominant_class = list(self.class_freq.keys())[idx % len(self.class_freq)]
                self.sample_to_class[idx] = dominant_class
                self.class_to_samples[dominant_class].append(idx)

    def get_temperature(self) -> float:
        """Get current temperature based on training progress."""
        if self.current_epoch >= self.num_epochs:
            return self.temperature_end

        # Linear annealing
        progress = self.current_epoch / max(self.num_epochs, 1)
        temperature = self.temperature_start + (self.temperature_end - self.temperature_start) * progress

        return float(temperature)

    def get_sampling_probabilities(self) -> Dict[int, float]:
        """Compute sampling probabilities for each class with current temperature."""
        temperature = self.get_temperature()

        # Apply temperature: prob_c = weight_c ^ (1/tau)
        probs = {}
        for class_id, weight in self.class_weights.items():
            probs[class_id] = weight ** (1.0 / max(temperature, 1e-6))

        # Normalize
        total_prob = sum(probs.values())
        if total_prob > 0:
            probs = {k: v / total_prob for k, v in probs.items()}

        return probs

    def sample_indices(self, num_samples: int) -> List[int]:
        """Sample indices with class-balanced strategy."""
        class_probs = self.get_sampling_probabilities()

        indices = []
        tail_count = 0

        for _ in range(num_samples):
            # Sample a class based on computed probabilities
            classes = list(class_probs.keys())
            probs = [class_probs[c] for c in classes]
            sampled_class = self.rng.choice(classes, p=probs)

            # Sample a random instance from this class
            if len(self.class_to_samples[sampled_class]) > 0:
                sampled_idx = self.rng.choice(self.class_to_samples[sampled_class])
                indices.append(int(sampled_idx))

                if sampled_class in self.tail_classes:
                    tail_count += 1

        # Ensure minimum tail ratio
        current_tail_ratio = tail_count / max(len(indices), 1)
        if current_tail_ratio < self.min_tail_ratio:
            num_to_replace = int(num_samples * self.min_tail_ratio) - tail_count
            for i in range(num_to_replace):
                if i < len(indices):
                    tail_class = self.rng.choice(list(self.tail_classes))
                    if len(self.class_to_samples[tail_class]) > 0:
                        indices[i] = int(self.rng.choice(self.class_to_samples[tail_class]))

        if self.shuffle:
            self.rng.shuffle(indices)

        return indices

    def __iter__(self) -> Iterator[int]:
        indices = self.sample_indices(len(self.dataset))
        return iter(indices)

    def __len__(self) -> int:
        return len(self.dataset)

    def set_epoch(self, epoch: int) -> None:
        self.current_epoch = epoch


def compute_class_frequency(labels: List[np.ndarray]) -> Dict[int, int]:
    """Utility to compute class frequency from a list of label arrays."""
    counter = Counter()
    for arr in labels:
        counter.update(arr.reshape(-1).tolist())
    return dict(counter)
