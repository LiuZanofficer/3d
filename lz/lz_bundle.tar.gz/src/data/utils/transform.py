from __future__ import annotations

import math
from typing import Any, Dict, List

import numpy as np
import torch


class Compose:
    def __init__(self, transforms_cfg: List[Dict[str, Any]]) -> None:
        self.transforms = [build_transform(cfg) for cfg in transforms_cfg]

    def __call__(self, data: Dict[str, Any]) -> Dict[str, Any]:
        for t in self.transforms:
            data = t(data)
        return data


def build_transform(cfg: Dict[str, Any]):
    t_type = cfg.get("type")
    if t_type is None:
        raise ValueError("Transform config missing 'type'")
    mapping = {
        "NormalizeColor": NormalizeColor,
        "RandomRotate": RandomRotate,
        "RandomFlip": RandomFlip,
        "RandomScale": RandomScale,
        "RandomSpatialCrop": RandomSpatialCrop,
        "RandomJitter": RandomJitter,
        "ToTensor": ToTensor,
        "Collect": Collect,
    }
    if t_type not in mapping:
        raise ValueError(f"Unknown transform type: {t_type}")
    cfg = dict(cfg)
    cfg.pop("type", None)
    return mapping[t_type](**cfg)


class NormalizeColor:
    def __init__(self, mean: float = 0.5, std: float = 0.5) -> None:
        self.mean = mean
        self.std = std

    def __call__(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if "color" in data:
            color = data["color"].astype(np.float32)
            color = color / 255.0
            color = (color - self.mean) / max(self.std, 1e-6)
            data["color"] = color
        return data


class RandomRotate:
    def __init__(self, axis: str = "z", angle: float = 360.0) -> None:
        self.axis = axis
        self.angle = angle

    def __call__(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if "coord" not in data:
            return data
        theta = np.deg2rad(np.random.uniform(0, self.angle))
        c, s = math.cos(theta), math.sin(theta)
        rot = np.eye(3, dtype=np.float32)
        if self.axis == "z":
            rot[:2, :2] = np.array([[c, -s], [s, c]], dtype=np.float32)
        elif self.axis == "y":
            rot[[0, 0, 2, 2], [0, 2, 0, 2]] = [c, s, -s, c]
        elif self.axis == "x":
            rot[[1, 1, 2, 2], [1, 2, 1, 2]] = [c, -s, s, c]
        coord = data["coord"].astype(np.float32)
        data["coord"] = coord @ rot.T
        return data


class RandomFlip:
    def __init__(self, axis: int = 0, prob: float = 0.5) -> None:
        self.axis = axis
        self.prob = prob

    def __call__(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if "coord" not in data:
            return data
        if np.random.rand() < self.prob:
            coord = data["coord"].astype(np.float32)
            coord[:, self.axis] = -coord[:, self.axis]
            data["coord"] = coord
        return data


class RandomScale:
    def __init__(self, scale_min: float = 0.9, scale_max: float = 1.1) -> None:
        self.scale_min = scale_min
        self.scale_max = scale_max

    def __call__(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if "coord" not in data:
            return data
        scale = np.random.uniform(self.scale_min, self.scale_max)
        data["coord"] = data["coord"].astype(np.float32) * scale
        return data


class RandomSpatialCrop:
    """Random XY crop for whole-scene training on limited GPU memory."""

    def __init__(
        self,
        crop_x: float = 4.0,
        crop_y: float = 4.0,
        min_points: int = 2048,
        max_retries: int = 10,
        recenter: bool = True,
    ) -> None:
        self.crop_x = float(crop_x)
        self.crop_y = float(crop_y)
        self.min_points = int(min_points)
        self.max_retries = int(max_retries)
        self.recenter = bool(recenter)

    @staticmethod
    def _to_numpy(x: Any) -> np.ndarray:
        if torch.is_tensor(x):
            return x.detach().cpu().numpy()
        return np.asarray(x)

    @staticmethod
    def _apply_mask(x: Any, mask: np.ndarray) -> Any:
        if torch.is_tensor(x):
            idx = torch.from_numpy(np.nonzero(mask)[0]).to(x.device)
            return x.index_select(0, idx)
        return x[mask]

    def _filter_caption_data(self, caption_data: Dict[str, Any], mask: np.ndarray) -> Dict[str, Any]:
        if "idx" not in caption_data or "caption" not in caption_data:
            return caption_data

        idx_list = caption_data.get("idx", [])
        cap_list = caption_data.get("caption", [])
        embed_list = caption_data.get("embed", None)
        has_embed = isinstance(embed_list, list)

        old_to_new = np.full(mask.shape[0], -1, dtype=np.int64)
        old_to_new[mask] = np.arange(int(mask.sum()), dtype=np.int64)

        new_idx = []
        new_caption = []
        new_embed = []

        for i, idx_item in enumerate(idx_list):
            idx_np = self._to_numpy(idx_item).astype(np.int64).reshape(-1)
            if idx_np.size == 0:
                continue
            idx_np = idx_np[(idx_np >= 0) & (idx_np < mask.shape[0])]
            if idx_np.size == 0:
                continue
            inside = mask[idx_np]
            if not inside.any():
                continue
            mapped = old_to_new[idx_np[inside]]
            if mapped.size == 0:
                continue

            new_idx.append(torch.from_numpy(mapped.astype(np.int32)).int())
            new_caption.append(cap_list[i] if i < len(cap_list) else "")
            if has_embed and i < len(embed_list):
                new_embed.append(embed_list[i])

        out = {"idx": new_idx, "caption": new_caption}
        if has_embed:
            out["embed"] = new_embed
        return out

    def __call__(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if "coord" not in data:
            return data

        coord = self._to_numpy(data["coord"]).astype(np.float32)
        if coord.shape[0] < self.min_points or coord.shape[1] < 2:
            return data

        mask = None
        half_x = self.crop_x * 0.5
        half_y = self.crop_y * 0.5

        for _ in range(max(self.max_retries, 1)):
            center_idx = np.random.randint(0, coord.shape[0])
            center = coord[center_idx, :2]
            cand = (
                (coord[:, 0] >= center[0] - half_x)
                & (coord[:, 0] <= center[0] + half_x)
                & (coord[:, 1] >= center[1] - half_y)
                & (coord[:, 1] <= center[1] + half_y)
            )
            if int(cand.sum()) >= self.min_points:
                mask = cand
                break

        if mask is None:
            return data

        for key in ("coord", "color", "segment", "instance", "origin_idx"):
            if key in data:
                data[key] = self._apply_mask(data[key], mask)

        if "caption_data" in data and isinstance(data["caption_data"], dict):
            data["caption_data"] = self._filter_caption_data(data["caption_data"], mask)

        if self.recenter and "coord" in data:
            if torch.is_tensor(data["coord"]):
                xy_mean = data["coord"][:, :2].float().mean(dim=0, keepdim=True)
                data["coord"][:, :2] = data["coord"][:, :2] - xy_mean
            else:
                xy_mean = data["coord"][:, :2].mean(axis=0, keepdims=True)
                data["coord"][:, :2] = data["coord"][:, :2] - xy_mean

        return data


class RandomJitter:
    def __init__(self, sigma: float = 0.005, clip: float = 0.02) -> None:
        self.sigma = sigma
        self.clip = clip

    def __call__(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if "coord" not in data:
            return data
        jitter = np.clip(
            np.random.normal(0.0, self.sigma, size=data["coord"].shape),
            -self.clip,
            self.clip,
        )
        data["coord"] = data["coord"].astype(np.float32) + jitter.astype(np.float32)
        return data


class ToTensor:
    def __call__(self, data: Dict[str, Any]) -> Dict[str, Any]:
        for k, v in list(data.items()):
            if isinstance(v, np.ndarray):
                if v.dtype == np.float64:
                    v = v.astype(np.float32)
                data[k] = torch.from_numpy(v)
        return data


class Collect:
    def __init__(self, keys: List[str]) -> None:
        self.keys = keys

    def __call__(self, data: Dict[str, Any]) -> Dict[str, Any]:
        return {k: data[k] for k in self.keys if k in data}
