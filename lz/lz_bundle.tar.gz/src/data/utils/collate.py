from __future__ import annotations

from typing import Any, Dict, List

import torch


def point_collate_fn(batch: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Collate function for point cloud batches."""
    batch = [b for b in batch if b is not None]
    if len(batch) == 0:
        return {}

    coords = []
    colors = []
    segments = []
    instances = []
    offsets = [0]
    scene_names = []
    caption_data = []

    for sample in batch:
        coord = torch.as_tensor(sample["coord"], dtype=torch.float32)
        if sample.get("color", None) is None:
            color = torch.zeros_like(coord)
        else:
            color = torch.as_tensor(sample["color"], dtype=torch.float32)
        coords.append(coord)
        colors.append(color)
        offsets.append(offsets[-1] + coord.shape[0])
        scene_names.append(sample.get("scene_name", ""))

        if "segment" in sample:
            segments.append(torch.as_tensor(sample["segment"], dtype=torch.long))
        if "instance" in sample:
            instances.append(torch.as_tensor(sample["instance"], dtype=torch.long))
        if "caption_data" in sample:
            caption_data.append(sample["caption_data"])

    batch_dict: Dict[str, Any] = {
        "coord": torch.cat(coords, dim=0),
        "color": torch.cat(colors, dim=0),
        "offset": torch.tensor(offsets, dtype=torch.int32),
        "scene_name": scene_names,
    }
    if segments:
        batch_dict["segment"] = torch.cat(segments, dim=0)
    if instances:
        batch_dict["instance"] = torch.cat(instances, dim=0)
    if caption_data:
        batch_dict["caption_data"] = caption_data
    return batch_dict
