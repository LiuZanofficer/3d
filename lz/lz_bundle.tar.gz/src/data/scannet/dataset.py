from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
import torch

from src.data.dataset_base import AnnotatedDataset
from src.data.metadata.scannet import (
    CLASS_LABELS_20,
    CLASS_LABELS_200,
    COMMON_CLASSES_200,
    HEAD_CLASSES_200,
    TAIL_CLASSES_200,
)
from src.utils import RankedLogger
from src.utils.io import unpack_list_of_np_arrays

log = RankedLogger(__name__, rank_zero_only=False)


class ScanNetDataset(AnnotatedDataset):
    CLASS_LABELS = CLASS_LABELS_20
    SEGMENT_FILE = "segment20.npy"
    INSTANCE_FILE = "instance.npy"
    LOG_POSTFIX = "scannet20"

    def __init__(
        self,
        data_dir: str,
        split: str,
        ignore_label: int = -100,
        repeat: int = 1,
        transforms: Optional[List[Dict]] = None,
        num_masks: Optional[int] = None,
        anno_sources: Optional[List[str]] = None,
    ) -> None:
        super().__init__(
            data_dir=data_dir,
            split=split,
            repeat=repeat,
            ignore_label=ignore_label,
            transforms=transforms,
            num_masks=num_masks,
            anno_sources=anno_sources,
        )


class ScanNet200Dataset(ScanNetDataset):
    CLASS_LABELS = CLASS_LABELS_200
    SEGMENT_FILE = "segment200.npy"
    INSTANCE_FILE = "instance.npy"
    LOG_POSTFIX = "scannet200"

    def build_subset_mapper(self):
        mapper = {}
        mapper["subset_names"] = ["head", "common", "tail"]
        for name in self.CLASS_LABELS:
            if name in HEAD_CLASSES_200:
                mapper[name] = "head"
            elif name in COMMON_CLASSES_200:
                mapper[name] = "common"
            elif name in TAIL_CLASSES_200:
                mapper[name] = "tail"
            else:
                raise ValueError(f"Unknown class name: {name}")
        return mapper


class ScanNet200DatasetGathered(ScanNet200Dataset):
    """ScanNet200 dataset with caption merging."""

    def load_caption(self, scene_name: str):
        scene_dir = self.data_dir / scene_name
        anno_source = np.random.choice(self.anno_sources)
        caption_file = scene_dir / f"captions.{anno_source}.npz"
        point_indices_file = scene_dir / f"point_indices.{anno_source}.npz"
        embed_file = scene_dir / f"caption_embeds.{anno_source}.npz"
        assert caption_file.exists(), f"{caption_file} not exist."
        assert point_indices_file.exists(), f"{point_indices_file} not exist."
        captions = unpack_list_of_np_arrays(np.load(caption_file, allow_pickle=True))
        point_indices = unpack_list_of_np_arrays(np.load(point_indices_file, allow_pickle=True))
        embeds = None
        if embed_file.exists():
            embeds = unpack_list_of_np_arrays(np.load(embed_file, allow_pickle=True))

        num_captions_per_object = [len(c) for c in captions]
        idx_select_caption = np.cumsum(
            np.insert(num_captions_per_object, 0, 0)[0:-1]
        ) + np.random.randint(0, num_captions_per_object, len(num_captions_per_object))

        point_indices = [torch.from_numpy(indices).int() for indices in point_indices]
        captions = [item for sublist in captions for item in sublist]
        captions = [captions[i] for i in idx_select_caption]
        embed_list = None
        if embeds is not None:
            embeds_flat = [item for sublist in embeds for item in sublist]
            embed_list = [
                torch.as_tensor(embeds_flat[i], dtype=torch.float32) for i in idx_select_caption
            ]

        if self.num_masks is not None and self.num_masks < len(point_indices):
            sel = np.random.choice(len(point_indices), self.num_masks, replace=False)
            point_indices = [point_indices[i] for i in sel]
            captions = [captions[i] for i in sel]
            if embed_list is not None:
                embed_list = [embed_list[i] for i in sel]

        out = dict(idx=point_indices, caption=captions)
        if embed_list is not None:
            out["embed"] = embed_list
        return out
