from __future__ import annotations

import json
from typing import Any, Callable, List, Optional

from lightning import LightningDataModule
from omegaconf import DictConfig
from torch.utils.data import DataLoader, Dataset

from src.data.multi_dataloader import ConcatDataset
from src.data.samplers.acbs_sampler import ACBSSampler
from src.data.utils.collate import point_collate_fn
from src.utils import RankedLogger

log = RankedLogger(__name__, rank_zero_only=True)


class DataModule(LightningDataModule):
    def __init__(
        self,
        train_dataset,
        val_datasets,
        batch_size: int,
        num_workers: int,
        collate_fn: Callable,
        pin_memory: bool = False,
        sampler: Optional[dict] = None,
        test_datasets: Optional[List] = None,
        test_batch_size: Optional[int] = None,
    ) -> None:
        super().__init__()

        self.save_hyperparameters(logger=False)

        self.data_train: Optional[Dataset] = None
        self.data_val: Optional[List[Dataset]] = None
        self.data_test: Optional[List[Dataset]] = None
        self._collate_fn = None
        self._train_sampler = None

    def setup(self, stage: Optional[str] = None) -> None:
        if stage in ["fit", None] and self.data_train is None:
            self.data_train = self.hparams.train_dataset

        if self.data_val is None:
            self.data_val = (
                self.hparams.val_datasets
                if isinstance(self.hparams.val_datasets, list)
                else [self.hparams.val_datasets]
            )

        if self.data_test is None and self.hparams.test_datasets is not None:
            assert self.hparams.test_batch_size is not None, "test_batch_size must be provided"
            self.data_test = (
                self.hparams.test_datasets
                if isinstance(self.hparams.test_datasets, list)
                else [self.hparams.test_datasets]
            )

        # resolve collate function
        if self._collate_fn is None:
            cf = self.hparams.collate_fn
            if cf is None:
                self._collate_fn = point_collate_fn
            elif isinstance(cf, DictConfig) and "_target_" in cf:
                from hydra.utils import instantiate

                self._collate_fn = instantiate(cf)
            else:
                self._collate_fn = cf

    def _build_sampler(self, dataset: Dataset):
        sampler_cfg = self.hparams.sampler
        if sampler_cfg is None:
            return None
        if sampler_cfg.get("name") != "acbs":
            return None
        freq_path = sampler_cfg.get("class_freq_path")
        if not freq_path:
            raise ValueError("sampler.class_freq_path must be provided for ACBS")
        with open(freq_path, "r", encoding="utf-8") as f:
            class_freq = {int(k): int(v) for k, v in json.load(f).items()}
        sampler = ACBSSampler(
            dataset=dataset,
            class_freq=class_freq,
            temperature_start=float(sampler_cfg.get("temperature_start", 0.5)),
            temperature_end=float(sampler_cfg.get("temperature_end", 1.0)),
            tail_boost_factor=float(sampler_cfg.get("tail_boost_factor", 2.0)),
            min_tail_ratio=float(sampler_cfg.get("min_tail_ratio", 0.3)),
            num_epochs=int(sampler_cfg.get("num_epochs", 100)),
            shuffle=bool(sampler_cfg.get("shuffle", True)),
            seed=int(sampler_cfg.get("seed", 42)),
        )
        return sampler

    def train_dataloader(self) -> DataLoader[Any]:
        if self.data_train is None:
            raise ValueError("No training dataset found. Please call `setup('fit')` first.")

        sampler = self._build_sampler(self.data_train)
        self._train_sampler = sampler
        return DataLoader(
            dataset=self.data_train,
            batch_size=self.hparams.batch_size,
            num_workers=self.hparams.num_workers,
            pin_memory=self.hparams.pin_memory,
            shuffle=(sampler is None),
            sampler=sampler,
            drop_last=True,
            collate_fn=self._collate_fn,
        )

    def set_epoch(self, epoch: int) -> None:
        """Sync epoch to samplers that support temperature/distributed annealing."""
        if self._train_sampler is not None and hasattr(self._train_sampler, "set_epoch"):
            self._train_sampler.set_epoch(epoch)
            if hasattr(self._train_sampler, "get_temperature"):
                temp = float(self._train_sampler.get_temperature())
                log.info(f"ACBS epoch={epoch} temperature={temp:.4f}")

    def val_dataloader(self) -> List[DataLoader[Any]]:
        return [
            DataLoader(
                dataset=dataset,
                batch_size=self.hparams.batch_size,
                num_workers=self.hparams.num_workers,
                pin_memory=self.hparams.pin_memory,
                shuffle=False,
                collate_fn=self._collate_fn,
            )
            for dataset in self.data_val
        ]

    def test_dataloader(self) -> List[DataLoader[Any]]:
        if self.data_test is None:
            return self.val_dataloader()

        return [
            DataLoader(
                dataset=dataset,
                batch_size=self.hparams.test_batch_size,
                num_workers=self.hparams.num_workers,
                pin_memory=self.hparams.pin_memory,
                shuffle=False,
                collate_fn=self._collate_fn,
            )
            for dataset in self.data_test
        ]
