from __future__ import annotations

from typing import List, Tuple

import numpy as np
from torch.utils.data import Dataset


class ConcatDataset(Dataset):
    """Lightweight concat dataset with repeat support."""

    def __init__(self, datasets: List[Dataset], repeat: int = 1) -> None:
        super().__init__()
        self.datasets = datasets
        self.repeat = repeat
        self.data_list: List[Tuple[int, int]] = self._build_data_list()

    def _build_data_list(self) -> List[Tuple[int, int]]:
        data_list: List[Tuple[int, int]] = []
        for i, dataset in enumerate(self.datasets):
            data_list.extend(zip(np.ones(len(dataset), dtype=int) * i, np.arange(len(dataset))))
        return data_list

    def __len__(self) -> int:
        return len(self.data_list) * self.repeat

    def __getitem__(self, idx):
        idx = idx % len(self.data_list)
        dataset_idx, data_idx = self.data_list[idx]
        return self.datasets[dataset_idx][int(data_idx)]

    def get_dominant_class(self, idx: int) -> int:
        idx = idx % len(self.data_list)
        dataset_idx, data_idx = self.data_list[idx]
        dataset = self.datasets[dataset_idx]
        if hasattr(dataset, "get_dominant_class"):
            return int(dataset.get_dominant_class(int(data_idx)))
        return 0
