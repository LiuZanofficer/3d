from __future__ import annotations

from typing import List

import numpy as np


def pack_list_of_np_arrays(arrays: List[np.ndarray]) -> dict:
    """Pack list of numpy arrays into a dict for np.savez."""
    return {str(i): arr for i, arr in enumerate(arrays)}


def unpack_list_of_np_arrays(npz_file) -> List[np.ndarray]:
    """Unpack list of numpy arrays from a np.load result."""
    data = npz_file
    if hasattr(npz_file, "files"):
        keys = sorted(npz_file.files, key=lambda x: int(x))
        return [npz_file[k] for k in keys]
    if isinstance(data, dict):
        keys = sorted(data.keys(), key=lambda x: int(x))
        return [data[k] for k in keys]
    raise ValueError("Unsupported npz container type.")
