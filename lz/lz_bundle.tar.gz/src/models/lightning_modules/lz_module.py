from __future__ import annotations

from typing import Any, Dict, List, Optional

import hydra
import lightning as L
import torch
import torch.nn.functional as F
from omegaconf import DictConfig, OmegaConf

from src.evaluation.tta_evaluator import TTAEvaluator
from src.models.losses.hpza_loss import HPZALoss
from src.models.losses.instance_loss import InstanceDiscriminativeLoss
from src.models.losses.pmtl_scheduler import PMTLScheduler
from src.models.losses.seg_loss import SegLoss
from src.models.networks.vlm.text_encoder import HashTextEncoder, build_text_encoder
from src.models.utils.metrics import compute_iou_from_conf, compute_subset_miou, update_confusion_matrix
from src.utils import RankedLogger

log = RankedLogger(__name__, rank_zero_only=True)


class LZLitModule(L.LightningModule):
    def __init__(
        self,
        net,
        optimizer: DictConfig,
        scheduler: Optional[DictConfig],
        scheduler_interval: str,
        loss_cfg: Dict,
        eval_cfg: Optional[Dict] = None,
        text_encoder_cfg: Optional[Dict] = None,
        best_metric: str = "val/miou",
        zero_shot: bool = False,
    ) -> None:
        super().__init__()
        self.save_hyperparameters(logger=False)

        self.net = net
        seg_cfg = loss_cfg.get("seg_loss", {})
        self.seg_loss = SegLoss(
            ignore_label=loss_cfg.get("ignore_label", -100),
            ce_weight=float(seg_cfg.get("ce_weight", 1.0)),
            lovasz_weight=float(seg_cfg.get("lovasz_weight", 0.0)),
            label_smoothing=float(seg_cfg.get("label_smoothing", 0.0)),
        )
        self.inst_loss = InstanceDiscriminativeLoss(
            ignore_label=loss_cfg.get("ignore_label", -100),
            delta_var=loss_cfg.get("instance_loss", {}).get("delta_var", 0.5),
            delta_dist=loss_cfg.get("instance_loss", {}).get("delta_dist", 1.5),
        )
        self.hpza_loss = HPZALoss(
            temperature=loss_cfg.get("hpza_loss", {}).get("temperature", 0.07),
            weight_caption=loss_cfg.get("hpza_loss", {}).get("weight_caption", 1.0),
            weight_class=loss_cfg.get("hpza_loss", {}).get("weight_class", 1.0),
        )
        self.pmtl = None
        if loss_cfg.get("pmtl") is not None:
            self.pmtl = PMTLScheduler(**loss_cfg["pmtl"])

        self.eval_cfg = eval_cfg or {}
        self.best_metric = best_metric
        self.zero_shot = zero_shot
        self.text_encoder_cfg = text_encoder_cfg or {"use_clip": False, "embed_dim": 768}
        self.text_encoder = None
        self.class_text_embeds = None
        self.class_names = None

        self.val_conf = {}
        self.val_class_names = {}
        self.val_subset_mapper = {}
        self.val_ignore_label = {}

        self.tta_evaluator = None
        if self.eval_cfg.get("use_tta", False):
            self.tta_evaluator = TTAEvaluator(
                rotations=self.eval_cfg.get("rotations", [0, 90, 180, 270]),
                flips=self.eval_cfg.get("flips", [False, True]),
                temperature=self.eval_cfg.get("temperature", 1.0),
                use_adapter_tta=self.eval_cfg.get("use_adapter_tta", True),
                adapter_steps=self.eval_cfg.get("adapter_steps", 1),
                adapter_lr=self.eval_cfg.get("adapter_lr", 1e-3),
                adapter_weight_decay=self.eval_cfg.get("adapter_weight_decay", 0.0),
                entropy_weight=self.eval_cfg.get("entropy_weight", 1.0),
            )

    def setup(self, stage: str) -> None:
        # build text encoder and class prototypes
        try:
            self.text_encoder = build_text_encoder(self.text_encoder_cfg)
        except Exception:
            log.warning("Falling back to HashTextEncoder.")
            self.text_encoder = HashTextEncoder(
                embed_dim=int(self.text_encoder_cfg.get("embed_dim", 768))
            )

        datamodule = getattr(self.trainer, "datamodule", None)
        if datamodule is not None and datamodule.data_train is not None:
            datasets = []
            if hasattr(datamodule.data_train, "datasets"):
                datasets = datamodule.data_train.datasets
            else:
                datasets = [datamodule.data_train]
            # pick dataset with most classes
            datasets = [d for d in datasets if hasattr(d, "CLASS_LABELS")]
            if datasets:
                datasets = sorted(datasets, key=lambda d: len(d.CLASS_LABELS), reverse=True)
                self.class_names = list(datasets[0].CLASS_LABELS)

        if self.class_names:
            with torch.no_grad():
                self.class_text_embeds = self.text_encoder.encode(
                    self.class_names, device=self.device
                )

        # validation dataset info
        if datamodule is not None and datamodule.data_val is not None:
            for idx, dataset in enumerate(datamodule.data_val):
                self.val_class_names[idx] = list(getattr(dataset, "CLASS_LABELS", []))
                self.val_subset_mapper[idx] = getattr(dataset, "subset_mapper", None)
                self.val_ignore_label[idx] = getattr(dataset, "ignore_label", -100)

    def _extract_caption_texts(self, caption_data: Any) -> List[str]:
        texts: List[str] = []
        if caption_data is None:
            return texts
        for cap in caption_data:
            for cap_text in cap.get("caption", []):
                texts.append(str(cap_text))
        return texts

    def _extract_caption_embeds(self, caption_data: Any) -> List[torch.Tensor]:
        embeds: List[torch.Tensor] = []
        if caption_data is None:
            return embeds
        for cap in caption_data:
            for emb in cap.get("embed", []):
                if isinstance(emb, torch.Tensor):
                    embeds.append(emb)
                else:
                    embeds.append(torch.as_tensor(emb))
        return embeds

    def _build_text_guidance(self, batch: Dict[str, Any]) -> Optional[torch.Tensor]:
        if self.text_encoder is None:
            return None
        with torch.no_grad():
            cached_embeds = self._extract_caption_embeds(batch.get("caption_data"))
            if cached_embeds:
                embed_tensor = torch.stack(
                    [e.to(device=self.device, dtype=torch.float32) for e in cached_embeds], dim=0
                )
                return embed_tensor.mean(dim=0)
            captions = self._extract_caption_texts(batch.get("caption_data"))
            if captions:
                text_embeds = self.text_encoder.encode(captions, device=self.device)
                if text_embeds.ndim == 2 and text_embeds.shape[0] > 0:
                    return text_embeds.mean(dim=0)
            if self.class_text_embeds is not None and self.class_text_embeds.numel() > 0:
                return self.class_text_embeds.mean(dim=0)
        return None

    def forward(
        self,
        batch: Dict[str, Any],
        apply_tta_adapter: bool = False,
    ) -> Dict[str, torch.Tensor]:
        text_guidance = self._build_text_guidance(batch)
        return self.net(
            batch,
            text_guidance=text_guidance,
            apply_tta_adapter=apply_tta_adapter,
        )

    def _compute_caption_alignment(self, text_feats, caption_data, offsets):
        if caption_data is None or self.text_encoder is None:
            return text_feats.sum() * 0.0

        cached_mask_feats = []
        cached_text_embeds = []
        online_mask_feats = []
        online_captions = []

        for b_idx, cap in enumerate(caption_data):
            base = int(offsets[b_idx])
            embed_list = cap.get("embed", [])
            for i, (idx_tensor, cap_text) in enumerate(zip(cap["idx"], cap["caption"])):
                if idx_tensor.numel() == 0:
                    continue
                global_idx = idx_tensor.to(text_feats.device) + base
                mask_feat = text_feats[global_idx].mean(dim=0)
                if i < len(embed_list):
                    emb = embed_list[i]
                    emb_t = emb if isinstance(emb, torch.Tensor) else torch.as_tensor(emb)
                    emb_t = emb_t.to(device=text_feats.device, dtype=mask_feat.dtype).view(-1)
                    if emb_t.numel() == mask_feat.numel():
                        cached_mask_feats.append(mask_feat)
                        cached_text_embeds.append(emb_t)
                    else:
                        online_mask_feats.append(mask_feat)
                        online_captions.append(str(cap_text))
                else:
                    online_mask_feats.append(mask_feat)
                    online_captions.append(str(cap_text))

        total_cnt = len(cached_mask_feats) + len(online_mask_feats)
        if total_cnt == 0:
            return text_feats.sum() * 0.0

        total_loss = text_feats.sum() * 0.0
        if cached_mask_feats:
            mask_feats = torch.stack(cached_mask_feats, dim=0)
            text_embeds = torch.stack(cached_text_embeds, dim=0)
            total_loss = total_loss + self.hpza_loss.caption_alignment(mask_feats, text_embeds) * (
                len(cached_mask_feats) / total_cnt
            )
        if online_mask_feats:
            mask_feats = torch.stack(online_mask_feats, dim=0)
            text_embeds = self.text_encoder.encode(online_captions, device=text_feats.device)
            total_loss = total_loss + self.hpza_loss.caption_alignment(mask_feats, text_embeds) * (
                len(online_mask_feats) / total_cnt
            )
        return total_loss

    def _compute_class_alignment(self, text_feats, labels):
        if labels is None or self.class_text_embeds is None:
            return text_feats.sum() * 0.0
        labels = labels.view(-1)
        text_feats = text_feats.view(labels.shape[0], -1)
        ignore_label = self.hparams.loss_cfg.get("ignore_label", -100)
        valid_mask = labels != ignore_label
        labels = labels[valid_mask]
        feats = text_feats[valid_mask]
        unique_ids = torch.unique(labels)
        if unique_ids.numel() == 0:
            return text_feats.sum() * 0.0
        class_feats = []
        class_text = []
        for cls_id in unique_ids:
            mask = labels == cls_id
            class_feats.append(feats[mask].mean(dim=0))
            if cls_id < self.class_text_embeds.shape[0]:
                class_text.append(self.class_text_embeds[int(cls_id)])
        if not class_feats or not class_text:
            return text_feats.sum() * 0.0
        class_feats = torch.stack(class_feats, dim=0)
        class_text = torch.stack(class_text, dim=0)
        return self.hpza_loss.class_alignment(class_feats, class_text)

    def training_step(self, batch, batch_idx):
        outputs = self(batch)
        seg_logits = outputs["seg_logits"]
        inst_embeddings = outputs["inst_embeddings"]
        text_feats = outputs["text_feats"]

        seg_loss = self.seg_loss(seg_logits, batch.get("segment"))
        inst_loss = self.inst_loss(inst_embeddings, batch.get("instance"))
        hpza_caption = self._compute_caption_alignment(
            text_feats, batch.get("caption_data"), batch["offset"]
        )
        hpza_class = self._compute_class_alignment(text_feats, batch.get("segment"))
        hpza_loss = hpza_caption + hpza_class

        weights = self.hparams.loss_cfg.get("weights", {})
        if self.pmtl is not None:
            weights = self.pmtl.get_weights(self.current_epoch)

        loss = (
            seg_loss * float(weights.get("seg_loss", 1.0))
            + inst_loss * float(weights.get("instance_loss", 1.0))
            + hpza_loss * float(weights.get("hpza_loss", 1.0))
        )

        self.log("train/loss", loss, on_step=True, on_epoch=True, prog_bar=True)
        self.log("train/seg_loss", seg_loss, on_step=True, on_epoch=True)
        self.log("train/inst_loss", inst_loss, on_step=True, on_epoch=True)
        self.log("train/hpza_loss", hpza_loss, on_step=True, on_epoch=True)
        return loss

    def on_train_epoch_start(self) -> None:
        datamodule = getattr(self.trainer, "datamodule", None)
        if datamodule is not None and hasattr(datamodule, "set_epoch"):
            datamodule.set_epoch(int(self.current_epoch))

    def on_validation_epoch_start(self) -> None:
        self.val_conf = {}
        for idx, names in self.val_class_names.items():
            num_classes = len(names)
            self.val_conf[idx] = torch.zeros(
                (num_classes, num_classes), dtype=torch.int64, device=self.device
            )

    def validation_step(self, batch, batch_idx, dataloader_idx: int = 0):
        if self.zero_shot and self.class_text_embeds is not None:
            outputs = self(batch)
            text_feats = F.normalize(outputs["text_feats"], dim=-1)
            class_text = F.normalize(self.class_text_embeds, dim=-1)
            seg_logits = text_feats @ class_text.t()
        elif self.tta_evaluator is not None:
            seg_logits = self.tta_evaluator(self, batch)
        else:
            seg_logits = self(batch)["seg_logits"]

        if "segment" not in batch:
            return
        preds = torch.argmax(seg_logits, dim=1)
        labels = batch["segment"]
        num_classes = len(self.val_class_names.get(dataloader_idx, []))
        if num_classes == 0:
            return
        conf = self.val_conf[dataloader_idx]
        self.val_conf[dataloader_idx] = update_confusion_matrix(
            conf,
            preds,
            labels,
            num_classes=num_classes,
            ignore_label=self.val_ignore_label.get(dataloader_idx, -100),
        )

    def on_validation_epoch_end(self) -> None:
        for idx, conf in self.val_conf.items():
            num_classes = conf.shape[0]
            if num_classes == 0:
                continue
            iou = compute_iou_from_conf(conf.float())
            miou = float(iou.mean().item())
            subset_vals = compute_subset_miou(
                iou,
                self.val_class_names[idx],
                self.val_subset_mapper.get(idx),
            )
            postfix = f"{idx}"
            self.log(f"val/miou_{postfix}", miou, prog_bar=True)
            if idx == 0:
                self.log("val/miou", miou, prog_bar=True)
            for k, v in subset_vals.items():
                self.log(f"val/{k}_{postfix}", v)
                if k.endswith("_miou"):
                    self.log(f"val/{k[:-5]}_{postfix}", v)

    def configure_optimizers(self):
        optimizer = hydra.utils.instantiate(self.hparams.optimizer, params=self.parameters())
        if self.hparams.scheduler is None:
            return optimizer

        scheduler_cfg = self.hparams.scheduler
        if isinstance(scheduler_cfg, DictConfig):
            scheduler_cfg = OmegaConf.create(
                OmegaConf.to_container(scheduler_cfg, resolve=True)
            )

        target = str(scheduler_cfg.get("_target_", ""))
        if target.endswith("OneCycleLR"):
            auto_total_steps = bool(scheduler_cfg.get("auto_total_steps", True))
            if auto_total_steps:
                scheduler_cfg["total_steps"] = max(int(self.trainer.estimated_stepping_batches), 1)
            if "auto_total_steps" in scheduler_cfg:
                del scheduler_cfg["auto_total_steps"]

        scheduler = hydra.utils.instantiate(scheduler_cfg, optimizer=optimizer)
        return {
            "optimizer": optimizer,
            "lr_scheduler": {
                "scheduler": scheduler,
                "interval": self.hparams.scheduler_interval,
            },
        }
