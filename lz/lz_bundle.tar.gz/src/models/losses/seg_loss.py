from __future__ import annotations

from typing import List

import torch
import torch.nn as nn
import torch.nn.functional as F


class SegLoss(nn.Module):
    def __init__(
        self,
        ignore_label: int = -100,
        ce_weight: float = 1.0,
        lovasz_weight: float = 0.0,
        label_smoothing: float = 0.0,
    ) -> None:
        super().__init__()
        self.ignore_label = ignore_label
        self.ce_weight = float(ce_weight)
        self.lovasz_weight = float(lovasz_weight)
        self.label_smoothing = float(label_smoothing)

    @staticmethod
    def _lovasz_grad(gt_sorted: torch.Tensor) -> torch.Tensor:
        p = gt_sorted.numel()
        if p == 0:
            return gt_sorted
        gts = gt_sorted.sum()
        intersection = gts - gt_sorted.float().cumsum(0)
        union = gts + (1.0 - gt_sorted).float().cumsum(0)
        jaccard = 1.0 - intersection / (union + 1e-7)
        if p > 1:
            jaccard[1:p] = jaccard[1:p] - jaccard[0 : p - 1]
        return jaccard

    def _lovasz_softmax(self, logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        valid = labels != self.ignore_label
        if valid.sum() == 0:
            return logits.sum() * 0.0

        probs = F.softmax(logits[valid], dim=-1)
        labels = labels[valid]
        num_classes = probs.shape[1]

        losses: List[torch.Tensor] = []
        for c in range(num_classes):
            fg = (labels == c).float()
            if fg.sum() == 0:
                continue
            class_pred = probs[:, c]
            errors = (fg - class_pred).abs()
            errors_sorted, perm = torch.sort(errors, descending=True)
            fg_sorted = fg[perm]
            grad = self._lovasz_grad(fg_sorted)
            losses.append(torch.dot(errors_sorted, grad))

        if not losses:
            return logits.sum() * 0.0
        return torch.stack(losses).mean()

    def forward(self, logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        if labels is None or logits.numel() == 0:
            return logits.sum() * 0.0

        total_loss = logits.sum() * 0.0

        if self.ce_weight > 0.0:
            ce_loss = F.cross_entropy(
                logits,
                labels,
                ignore_index=self.ignore_label,
                label_smoothing=max(self.label_smoothing, 0.0),
            )
            total_loss = total_loss + self.ce_weight * ce_loss

        if self.lovasz_weight > 0.0:
            lovasz_loss = self._lovasz_softmax(logits, labels)
            total_loss = total_loss + self.lovasz_weight * lovasz_loss

        return total_loss
